CREATE DATABASE chocodb;

USE chocodb;

CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    description TEXT,
    price DOUBLE
);

INSERT INTO products (name, description, price) VALUES
('Dark Chocolate', 'Rich dark chocolate made with 70% cocoa.', 150.0),
('Milk Chocolate', 'Creamy milk chocolate.', 120.0),
('Hazelnut Truffle', 'Chocolate truffle with hazelnut center.', 200.0);
