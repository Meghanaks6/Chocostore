package com.chocostore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChocoStoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChocoStoreApplication.class, args);
    }
}