package com.chocostore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;

import java.util.*;

@Controller
public class ChocoController {

    private Map<String, String> users = new HashMap<>();
    private Map<String, String> names = new HashMap<>();

    private List<Map<String, Object>> productList = Arrays.asList(
            Map.of("name", "Dark Chocolate", "description", "Rich dark chocolate made with 70% cocoa.", "price", 150.0),
            Map.of("name", "Milk Chocolate", "description", "Creamy milk chocolate.", "price", 120.0),
            Map.of("name", "Hazelnut Truffle", "description", "Chocolate truffle with hazelnut center.", "price",
                    200.0));

    // Store all orders in memory
    private List<Map<String, Object>> orders = new ArrayList<>();
    private int orderCounter = 1; // for unique order IDs

    // ---------- Home ----------
    @GetMapping("/")
    public String home(HttpSession session, Model model) {
        String email = (String) session.getAttribute("email");
        if (email != null) {
            model.addAttribute("welcomeMessage", "Welcome, " + names.get(email) + "!");
        }
        addCartCount(session, model);
        return "home";
    }

    // ---------- Pages ----------
    @GetMapping("/about")
    public String about(HttpSession session, Model model) {
        addCartCount(session, model);
        return "about";
    }

    @GetMapping("/products")
    public String products(Model model, HttpSession session) {
        model.addAttribute("products", productList);
        addCartCount(session, model);
        return "products";
    }

    @GetMapping("/cart")
    public String cart(HttpSession session, Model model) {
        List<Map<String, Object>> cart = getCart(session);
        double total = cart.stream().mapToDouble(p -> (Double) p.get("price")).sum();

        model.addAttribute("cart", cart);
        model.addAttribute("total", total);
        addCartCount(session, model);
        return "cart";
    }

    @GetMapping("/contact")
    public String contact(HttpSession session, Model model) {
        addCartCount(session, model);
        return "contact";
    }

    // ---------- Cart ----------
    @PostMapping("/cart/add")
    public String addToCart(@RequestParam String name,
            @RequestParam double price,
            HttpSession session) {
        List<Map<String, Object>> cart = getCart(session);

        Map<String, Object> item = new HashMap<>();
        item.put("name", name);
        item.put("price", price);
        cart.add(item);

        session.setAttribute("cart", cart);
        return "redirect:/cart";
    }

    // ---------- Checkout ----------
    @GetMapping("/checkout")
    public String checkout(HttpSession session, Model model) {
        List<Map<String, Object>> cart = getCart(session);
        if (cart.isEmpty()) {
            return "redirect:/cart";
        }

        // Generate order
        Map<String, Object> order = new HashMap<>();
        order.put("orderId", orderCounter++);
        order.put("items", new ArrayList<>(cart));
        double total = cart.stream().mapToDouble(p -> (Double) p.get("price")).sum();
        order.put("total", total);
        orders.add(order);

        session.removeAttribute("cart"); // clear cart after checkout
        addCartCount(session, model);
        model.addAttribute("orderId", order.get("orderId"));
        return "checkout";
    }

    // ---------- Orders ----------
    @GetMapping("/orders")
    public String ordersPage(HttpSession session, Model model) {
        model.addAttribute("orders", orders);
        addCartCount(session, model);
        return "orders";
    }

    // ---------- Login ----------
    @GetMapping("/login")
    public String loginPage(HttpSession session, Model model) {
        addCartCount(session, model);
        return "login";
    }

    @PostMapping("/login")
    public String login(HttpSession session,
            @RequestParam String email,
            @RequestParam String password,
            Model model) {
        if (users.containsKey(email) && users.get(email).equals(password)) {
            session.setAttribute("email", email);
            return "redirect:/";
        } else {
            model.addAttribute("error", "Invalid username or password");
            addCartCount(session, model);
            return "login";
        }
    }

    // ---------- Signup ----------
    @GetMapping("/signup")
    public String signupPage(HttpSession session, Model model) {
        addCartCount(session, model);
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@RequestParam String name,
            @RequestParam String email,
            @RequestParam String password,
            Model model,
            HttpSession session) {
        if (users.containsKey(email)) {
            model.addAttribute("error", "User already exists");
            addCartCount(session, model);
            return "signup";
        }
        users.put(email, password);
        names.put(email, name);

        model.addAttribute("success", "Signup successful! Please login.");
        addCartCount(session, model);
        return "login";
    }

    // ---------- Logout ----------
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    // ---------- Helpers ----------
    private List<Map<String, Object>> getCart(HttpSession session) {
        List<Map<String, Object>> cart = (List<Map<String, Object>>) session.getAttribute("cart");
        if (cart == null)
            cart = new ArrayList<>();
        return cart;
    }

    private void addCartCount(HttpSession session, Model model) {
        List<Map<String, Object>> cart = (List<Map<String, Object>>) session.getAttribute("cart");
        model.addAttribute("cartNotEmpty", cart != null && !cart.isEmpty());
        model.addAttribute("hasOrders", !orders.isEmpty());
    }
}
